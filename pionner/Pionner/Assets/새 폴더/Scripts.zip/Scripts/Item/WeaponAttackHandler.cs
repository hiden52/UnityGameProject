using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponAttackHandler : MonoBehaviour
{
    [SerializeField] public WeaponItem CurrentWeapon { get; private set; }


    
}
