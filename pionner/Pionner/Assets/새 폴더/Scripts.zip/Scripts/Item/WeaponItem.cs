using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponItem : EquipmentItem, IWeaponItem
{
    public WeaponItem(EquipmentItemData weaponItemData) : base(weaponItemData)
    {

    }

    public void Attack()
    {

    }
}
