using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStat : MonoBehaviour, IDamageable
{
    [SerializeField] private float maxHp = 100f;
    private float currentHp;

    public float MaxHp => maxHp;
    public float CurrentHp => currentHp;
    public bool IsDead => currentHp <= 0f;

    public event Action OnHealthChanged;
    public event Action OnDead;

    private void Awake()
    {
        currentHp = maxHp;
    }

    public void TakeDamage(float amount)
    {
        currentHp = Mathf.Clamp(currentHp - amount, 0f, maxHp);
        OnHealthChanged?.Invoke();

        if (IsDead)
        {
            OnDead?.Invoke();
        }
    }

    public void Heal(float amount)
    {
        currentHp = Mathf.Clamp(currentHp + amount, 0f, maxHp);
        OnHealthChanged?.Invoke();
    }
}

