using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MineableObject : DefaultObject, IDamageable, IInteratable
{
    [SerializeField] private CountableItemData itemData;
    [SerializeField] private float maxDurability = 5;
    [SerializeField] private float currentDurability;
    [SerializeField] private Collider collider;
    [SerializeField] private GameObject rock;
    [SerializeField] private GameObject debris;

    public bool IsDead => currentDurability <= 0;

    private void Awake()
    {
        collider = GetComponent<Collider>();
        currentDurability = maxDurability;
    }

    private void OnEnable()
    {
        debris.SetActive(false);
        rock.SetActive(true);
        collider.enabled = true;
    }

    public void TakeDamage(float amount)
    {
        currentDurability = Mathf.Max(0, currentDurability - amount);
        if (IsDead)
        {
            HarvestComplete();
        }
    }

    public void Interact()
    {
        TakeDamage(1);
    }

    private void HarvestComplete()
    {
        collider.enabled = false;
        Destroy(rock);
        debris?.SetActive(true);
        InventoryManager.Instance.AddItem(itemData, 1);

        Destroy(debris, 3f);
        
    }
}
