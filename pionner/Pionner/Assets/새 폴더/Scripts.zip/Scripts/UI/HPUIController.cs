using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HPUIController : MonoBehaviour
{
    [SerializeField] private Image HpBar;
    [SerializeField] private Text HpText;
    [SerializeField] private float currentHP;
    [SerializeField] private float maxHP;

    private void Update()
    {
        SetHP();
    }
    public void SetHP()
    {
        SetHPBar();
        SetHPtext();
    }

    private void SetHPBar()
    {
        HpBar.fillAmount = (currentHP / maxHP);
    }
    private void SetHPtext()
    {
        HpText.text = $"{Mathf.FloorToInt(currentHP)} / {Mathf.FloorToInt(maxHP)}";
        
    }



}
