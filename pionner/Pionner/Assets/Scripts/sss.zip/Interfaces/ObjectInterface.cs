using System.Collections;
using System.Collections.Generic;
using UnityEngine;

interface IInteratable
{
    public void Interact();
}

