using System.Collections;
using System.Collections.Generic;
using UnityEngine;

interface IItemSlot
{
    public bool HasItem();
    public Item GetItem();
}


