public struct DamageInfo
{
    public float DamageAmount;
    public WeaponType Type;
}