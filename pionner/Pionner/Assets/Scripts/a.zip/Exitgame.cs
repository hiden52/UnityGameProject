using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Exitgame : MonoBehaviour
{
    public void QuitGame()
    {
        Application.Quit();
    }
}
