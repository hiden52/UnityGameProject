public interface IIBuildingActions
{
    public void BuildingAction();
}