interface IWeaponItem
{
    public void Attack();
}

interface IArmorItme
{
    
}
