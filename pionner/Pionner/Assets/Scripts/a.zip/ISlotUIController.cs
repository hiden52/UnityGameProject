public interface ISlotUIController
{
    public void MoveOrSwapItem(int sourceIndex, int targetIndex);
}