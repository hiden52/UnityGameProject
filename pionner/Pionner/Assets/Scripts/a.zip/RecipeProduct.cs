[System.Serializable]
public struct RecipeProduct
{
    public ItemData itemData;
    public int amount;
}