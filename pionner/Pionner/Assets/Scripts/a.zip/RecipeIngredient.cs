[System.Serializable]
public struct RecipeIngredient
{
    public ItemData itemData;
    public int amount;
}